#include <stdlib.h>
#include <stdio.h>
#include <math.h>


int main(void){
      printf("Entrez la taille de trois côtés: ");
      float c1;
      scanf("%f",&c1);
      float c2;
      scanf("%f",&c2);
      float c3;
      scanf("%f",&c3);

      if(c1<=0 || c2<=0 || c3<=0 ){
            printf("Une taille de côté doit être strictement positive !\n");
      }
      else if(c1+c2<=c3 || c1+c3<=c2 || c2+c3<=c1 ){
            //La taille du plus grand côté doit être plus petite que la sommme de la
            //taille des trois autres côtés !
            printf("Il est impossible de construire un triangle avec ces tailles de côté !\n");
      }
      else if(c1==c2 && c2==c3 && c3==c1){
            printf("C'est un triangle equilatéral !\n");
      }
      else if((c1==c2 ) || (c2 == c3 ) || (c3 == c1 )){
            printf("C'est un triangle isocèle !\n");
      }
     else if(c1==sqrt((c2*c2)+(c3*c3))|| c2==sqrt((c1*c1)+(c3*c3))||c3==sqrt((c1*c1)+(c2*c2)) ){
     
            printf("C'est un triangle rectangle ?\n");
         
      }
      else{
            printf("C'est un triangle quelconque.\n");
      }
      
      
      return 0;
    }


