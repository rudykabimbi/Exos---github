/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#define PI 3.14159265359

int main(void)
{
    float rayon=0.0;
    float cote=0.0;
    float aire_carre=0.0;
    float aire_cercle=0.0;
    float aire_intersection=0.0;
    
    printf("veuillez entrer la taille du côté du carré?");
    scanf("%f",&cote);
    rayon=cote/2.0;
    
   
    
    aire_cercle=PI*rayon*rayon;
    aire_carre=cote*cote;
    aire_intersection=aire_carre-aire_cercle;
    printf("Le carré dont un coté est %.2f à une aire de %.2f , dès lors l'air du cercle est %.2f et l'air de l'intersection est %.2f",cote,aire_carre,aire_cercle,aire_intersection);
    
    
    
    
    

    return 0;
}

