/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(void)
{
   int a,b,c,maximum;
  
   
   printf("Bienvenu dans le programme qui calcule le maximum d'une série de 3 chiffres\n\n"); 
   printf("Veuillez encoder le premier chiffre entier");
   scanf("%i",&a);
   printf("Veuillez encoder le second chiffre entier");
   scanf("%i",&b);
   printf("Veuillez encoder le troisième chiffre entier");
   scanf("%i",&c);
   printf("\n les chiffres que vous avez choisis sont :\n %i  \n %i \n %i\n \n",a,b,c);
   if (a>=b && a>=c)
   //ATTENTION: 
   //si je mets uniquement plus grand et que je tape le même numéro sur les deux premieres phases..
   //il ne va pas les considérer comme plus grand et ce sera don le C qui sera choisi même si plus petit
   {    
        maximum=a;
       
   }
   else if (b>=a && b>=c)
   {
        maximum=b;
        
   }
   else 
        maximum=c;
    printf("La valeur maximum est:%i ",maximum);
    return 0;
}
