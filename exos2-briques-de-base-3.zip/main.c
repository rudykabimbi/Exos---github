/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdlib.h> 
#include <stdio.h> 
#define PHI 1.6103398875  

int main(void)

{     
    printf("Quelle est la largeur que vous voulez entrer pour votre rectangle d'or ? ");
    float largeur; 
    scanf("%f",&largeur);   
    printf("La longeur de votre rectangle d'or d'une largeur de %f est : %f",largeur,largeur*PHI);
    
    return 0;
    
    
}